# Python - List collection

# There are different collections in Python
# We will see how to work with lists

x=[1,3,5]
print(x)
print(x[1])
x[1]=10
x.append(20)
print(x)

Courses=["AZ-400","DP-203","AZ-104"]
for x in Courses:
  print(x)