# Python - while construct

x=10
while x>5:
    print(x)
    x=x-1
