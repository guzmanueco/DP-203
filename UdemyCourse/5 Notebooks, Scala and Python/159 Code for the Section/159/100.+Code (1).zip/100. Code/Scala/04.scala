// Scala - case construct

val i=100
i match{
  case i if i<50 => println("The value is less than 50")
  case i if i>50 => println("The value is greater than 50")
}
