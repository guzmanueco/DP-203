// Scala - Functions
def add(x:Int,y:Int):Int={
  return(x+y)
}

  println("The sum of the values 1090 + 90 = " + add(1090,90))

