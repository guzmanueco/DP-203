// Lab  - Time Travel

%sql
DESCRIBE HISTORY newmetrics


%sql
SELECT * FROM newmetrics VERSION AS OF 3
