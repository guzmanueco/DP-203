// This is a magic command to look into the DBFS file system

%fs ls 

// The below command can be used to create a new directory

%fs mkdirs mydir